// Javascript is a both front end as well as backend language and Javascript becoming so pupolar and also in future Everyone will learn it
// I this course I have Referred MDN Documentation and Its the best documentation to learn Javascript
// link for MDN Documentation : https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/JavaScript_basics
// Best Videos to learn Javascript is : https://courses.learncodeonline.in/learn/Complete-Javascript-course Hitesh Choudary one of the famous Youtuber Who teaches toghest topics in a easiest manner
// Here to compile tha javascript code we are using nodejs Its a Javascript Runtime Environment
// So Download and install Nodeja from https://nodejs.org/en/download/
// Make a research on ES6.
// Print statement in javascript Console.The console also u can easily find in the browser

console.log("Hello Pace Wisdom Solution");




