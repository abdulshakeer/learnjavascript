var title = document.getElementsByTagName("h1")[0].innerHTML
var titleTwo = document.getElementsByClassName("title")[0].innerHTML

console.log(title);
console.log(titleTwo);